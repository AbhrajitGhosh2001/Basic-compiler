

public class EvaluateIntMathOp {
	Node node;
	EvaluateIntMathOp(Node node){
		this.node=node;
	}

}
