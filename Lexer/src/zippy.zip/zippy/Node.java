/*
 * This is the abstract class all Nodes derive from
 */

public abstract class Node {

	public abstract String toString();
	
	
}
